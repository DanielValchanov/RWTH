public class ImprovedSelectionSort {

    public static void sort(int[] a) {
        for(int i = 0; i < a.length - 1 - i; i++)
        {
            int min = i, max = i;
            for(int j = i + 1; j < a.length - i; j++)
            {
                //a[min] <= a[max], min <= j
                if(a[j] < a[min])
                    min = j;
                else if(a[j] >= a[max])
                    max = j;
                // Entweder a[min] verkleinert sich oder max := j + 1, oder nichts ändert sich.
                // Fall 1: a[min] verkleinert sich, also a[min] < a[max]
                // Fall 2: max := j + 1 > j >= min, also max > min
                // Fall 3: das würde bedeuten, dass a[j] >= a[min] und a[j] < a[max], also a[max] > a[min]
            }
            // Nach jedem Durchlauf der Schleife gilt entweder max > min oder a[max] > a[min], also max != min
            // Vor der Schleife gilt jedoch max = min
            // Daher max = min genau dann, wenn i = a.length - 1 - i, was bedeutet, dass das Interval [i, a.length - i) = [i,i] schon sortiert sein muss
            int n = a.length - 1 - i;
            if(min == max)
                continue;
            else if(min == i && max == n)
                continue;
            else if(min == n && max == i)
            {
                int temp = a[i]; // == a[max]
                a[i] = a[n];
                a[n] = temp;
            }
            else if(min == i)
            {
                int temp = a[max];
                a[max] = a[n];
                a[n] = temp;
            }
            else if(min == n)
            {
                int temp = a[n]; // == a[min]
                a[n] = a[i];
                a[i] = temp;
                temp = a[max];
                a[max] = a[n];
                a[n] = temp;
            }
            else if(max == n)
            {
                int temp = a[min];
                a[min] = a[i];
                a[i] = temp;
            }
            else if(max == i)
            {
                int temp = a[i]; // == a[max]
                a[i] = a[n];
                a[n] = temp;
                temp = a[min];
                a[min] = a[i];
                a[i] = temp;
            }
            else
            {
                int temp = a[min];
                a[min] = a[i];
                a[i] = temp;
                temp = a[max];
                a[max] = a[n];
                a[n] = temp;
            }
        }
    }

}
