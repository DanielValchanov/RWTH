public class Rechteck {
  
  double laenge, breite;

  int strichstaerke;

  double flaeche () {
    return laenge * breite;
  }
}
